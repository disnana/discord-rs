pub mod botref;
pub mod cert_policy;
pub mod child_recovery;
pub mod cluster;
pub mod cluster_runtime;
mod cogs;
#[cfg(unix)]
pub mod core_attach;
#[cfg(unix)]
pub mod core_server;
pub mod core_state;
#[cfg(unix)]
pub mod core_units;
pub mod daemon;
pub mod daemon_metrics;
pub mod drain;
pub mod durable_jobs;
pub mod event_seq;
pub mod failover;
pub mod fs_perms;
pub mod gateway_metadata;
pub mod gateway_switch;
pub mod identify;
pub mod interaction_flow;
pub mod local_control;
pub mod local_identify;
pub mod metrics;
pub mod metrics_feed;
pub mod ownership;
pub mod placement;
pub mod protocol;
pub mod raft_quorum;
pub mod rbac_audit;
pub mod redact;
pub mod response_drain;
pub mod rest_budget;
pub mod sd_notify;
pub mod secret_file;
pub mod shard_runtime;
pub mod state_store;
pub mod subscription;
pub mod supervisor;
pub mod switch;
pub mod testkit;
pub mod tls_transport;
pub mod update_gate;
pub mod update_rollback;
pub mod worker;

pub type AppError = Box<dyn std::error::Error + Send + Sync>;

/// Command definitions linked into this binary. Startup must reject duplicates.
pub fn registered_commands() -> bot_framework::BotResult<Vec<&'static bot_framework::Command>> {
    // Reference the module to ensure its static registrations are linked.
    let _ = cogs::build_id();
    bot_framework::commands()
}
