# 開発計画・引き継ぎ

## 基準と現状
2026-11-11、`tp-li-dev/discord-rs` の main（0843664）を取得。仕様は architecture.md。既存実装は単一 Shard の Gateway、2 Worker の stdin/stdout JSON IPC、管理プロセスと更新 CLI。Worker は token を継承しない。更新は Worker ごとに順次行われ、途中失敗時に新旧が混在する。状態は親プロセスのメモリのみ。仕様の shard 単位 Gateway/Core、複数 Bot、分散制御、属性マクロ、ハイブリッドコマンドは未実装。

## 段階計画
1. 既存動作のテストと IPC・管理経路の境界を整える。フレーム上限は暫定 1 MiB、既存の大きい状態が超過すると拒否されるため、状態の分割や永続化を含めて再設計する。
2. 仕様 §16 の順序で開発者 API・マクロ、Shard 単位の Gateway/Core とバージョン付き IPC、drain と応答確認を構築し、既存機能を移行する。
3. 複数 Bot の Daemon/CLI と認証済み管理を構築する。既存ローカル管理の Windows ACL、要求制限、ログとトークンの取り扱いを検証する。
4. 成熟した consensus 実装を評価し quorum と lease/fencing を実装、分断時は安全に停止する。独自 Raft は実装しない。
5. 仕様 T01–T20、Linux/Windows、実 Discord・複数ホスト障害注入・性能を検証し、環境、失敗数、p95/p99 と未達を記録する。

## 設計判断・未解決
Gateway 並行接続による欠落ゼロや exactly-once は未保証。静的登録方式、IPC codec、consensus ライブラリ、lease の時間安全性は仕様 §17 に従い検証して決定する。既存 Worker は Shard ではなく、仕様の Core の代替として完成扱いしない。実 Discord、Windows、複数ホストの試験環境は未確認。本番デプロイ、破壊的操作、秘密情報の変更には事前確認を要する。

## 今回の変更と検証
Worker の双方向受信に 1 MiB、管理要求に 4095 byte（改行込み）の上限を設け、未終端を拒否する。境界・超過・未終端の単体テストを追加。Linux / Rust 1.99.1 で単体テスト3件、管理統合テスト1件が通過。`cargo fmt` と `cargo clippy --all-targets -- -D warnings` 通過。`cargo test` は単体3件・統合5件すべて通過（更新コマンドの release ビルドを含む）。Windows、Discord、性能、分断試験は未実施。管理クライアント側の応答読み取り制限、IPC のサイズ制限と大規模状態移行の設計は残る。

## 追加計画：依存関係を考慮した並行開発
開発者 API の最小ハイブリッドコマンドと、IPC handshake・drain の基礎を独立して並行実装する。まず模擬入力でコンパイル・ルーティングを検証し、次に実 Gateway/Core の IPC・REST 応答へ接続する。その後に daemon と複数 Bot、Core の世代切替、Gateway 並行接続、quorum/lease と障害試験を順に進める。各段階は小規模な動作テストを通して前進し、実 Discord・Windows・複数ノードでのみ確認できる保証は未検証として残す。開発中の細かい改善は最終監査で調整するが、認証、秘密分離、分断時の安全性は最初から維持する。

## 並行開発の結果
- `framework` と `framework-macros` に属性マクロ・inventory 登録・重複検出・共通ディスパッチを試作。模擬入力で検証済み。Discord、IPC、型付き引数、Cog、イベントには未接続。
- `DrainTracker` は受付停止と子処理を含む完了待ちを提供。既存 Worker・REST 応答確認・IPC 排出には未接続。
- Worker Ready に互換性のある範囲と必須 capability の検査を追加。旧 v5 は許容。旧親は新必須 capability を検証しないため新たな必須機能では protocol を上げる。双方向交渉と Bot/Shard/世代照合は未実装。
- reload ビルド子プロセスから DISCORD_TOKEN を除外。Linux/Windows CI を追加したが Actions 実行結果は未確認。
- Linux / Rust 1.99.1 で `cargo fmt --all --check`、`cargo clippy --workspace --all-targets -- -D warnings`、`cargo test --workspace` 成功。次は試作 API を既存 Worker の prefix 経路へ接続し、slash と REST 応答を同じ Gateway/Core 経路に接続する。compile-fail テストと Discord 実接続、Windows、ベンチマークは未実施。

## 継続開発：prefix 統合と安全なサイズ拒否
- `!ping` を属性マクロで登録し、既存 Worker の IPC 経由で実行。count/job は既存経路を維持。実 Worker のテストを追加。Slash、型付き引数、実 Discord は未接続。
- マクロの誤った関数定義について compile-fail 4例を追加。Gateway/Core の識別子・制御/データ・結果不明の型を追加したが、通信・認証・fencing には未接続。
- レビューでサイズ上限超過による状態巻き戻りを発見。現行ローカル状態を変更前に保持し、フレーム上限超過時は拒否して Worker と既存状態を維持する。実プロセス試験で確認。外部副作用には適用不可。状態コピーと複数回シリアライズのコストは未測定で、分割・永続化・ACK を後続で設計する。
- 管理クライアントの応答にも 64 KiB の上限を追加。管理ループの直列処理による遅延は残る。
- Linux Rust 1.99.1: `cargo fmt --all`、`cargo clippy --workspace --all-targets -- -D warnings`、`cargo test --workspace` 成功。初回テストはサンドボックスの TCP bind 制限で失敗、ネットワーク権限付きで再実行し通過。Windows/Discord/性能は未検証。
- 次は Interaction の受付と初回応答期限・応答帰属を設計し、実 Gateway/Core 経路へ接続する。型だけで認証やリースを実装したと見なさない。

## 2026-11-12：Interaction と配置の基礎
- 引数なしの登録済み ChatInput を Gateway で受け、defer 後、専用 IPC コマンドとして Worker に転送し元 Interaction を編集する試作を追加。旧 prefix と同名でも専用経路で実行し、旧 Worker が capability を広告しなければ送信せず拒否する。spawn 前に同時実行上限を適用し、初回 ACK は2秒、編集は10秒で打ち切る。ACK の結果不明時に処理を実行・再送しない。飽和時は未応答で Discord が失敗表示する。登録は Discord の既存コマンドの上書きを避けるため自動実行しない。実 Discord・HTTP・3秒期限・応答確認は未検証。
- ReadyEvent の属性登録と順序付きディスパッチを試作。Gateway/IPC は未接続。Bot/Shard 配置の重複・範囲・token 環境変数名の検証を追加。実配置・所有権には未接続。
- DrainTracker の受付競合と取消試験を追加。現在の REST 送信は Worker Manager の外にあるため、応答確認前に drain 完了と判定しないよう実切替への接続は保留。切替失敗時の受付再開も要設計。
- Linux Rust 1.99.1 で fmt、workspace clippy（警告禁止）、workspace 全テスト成功。Windows CI は未実行。次は Interaction HTTP の模擬統合テストとコマンド登録の非破壊な運用設計、実経路の REST 応答追跡と drain 統合を進める。

## 継続：応答試験・管理・設定
- Interaction の ACK 成功/失敗/期限と元 Interaction への応答帰属を模擬 Future でテスト。実 HTTP は未検証。Ready イベントを Gateway から Worker IPC に配送（旧 Worker の capability を確認、pool index 0 のみ）。
- 配置 TOML の読込・サイズ制限・構文検査、オフライン doctor を追加。`cargo run --bin doctor -- examples/placement.toml --resolved-shards bot-two=1`。Daemon と Discord は診断しない。
- 未認証の管理接続を有限の並行読取へ分離し、アイドル接続中の監視・status 継続を実プロセスで検証。認証済みの操作と更新ビルドは依然直列。
- 応答 drain 基盤は取消・timeout の結果不明を追跡するが実切替未接続。REST 送信と世代追跡の原子性、失敗時の受付再開、結果不明の照合を設計中。
- Linux fmt/clippy/workspace test は上記の統合時点で成功。その後追加した doctor と型付き StateMap は個別テスト成功、全体再検証が必要。Windows・実 Discord・性能は未検証。

## 継続：状態・応答追跡
- 型付き StateMap を Worker の command/Ready Context に接続。Worker ごとに独立し、更新・再起動で初期化される。永続状態ではない。
- 単一 Slash コマンド登録 CLI は既定 dry-run。`cargo run --bin register -- <application-id> <global|guild-id> ping` で計画を表示し、`--apply` は同名同スコープ1件を上書きする。実登録未実施。
- コマンドの通常エラーが Worker を落とす回帰を修正。現行メモリ状態の復元は外部副作用を取り消さない。
- Worker 更新は進行中の外部応答を待ち、結果不明があれば旧 Worker を維持。実プロセステスト2件通過。通常メッセージ送信にも10秒期限を追加。結果不明の照合・解除と永続化は未実装、解消まで更新を拒否し、再起動で追跡は消える。現状は全 Worker の応答受付が更新中に待機し、新旧並行 drain ではない。
- Linux workspace test/fmt/clippy は応答追跡と型付き状態の統合時点で成功。後続の HTTP timeout 等の変更について再検証する。Windows、実 Discord、複数ホスト、性能は未検証。

## 継続：Worker 単位の受付と Cog
- 更新ゲートを Worker ごとに分離し、別 Worker の処理継続と部分更新を統合試験で確認。途中の結果不明は旧 Worker を維持し、既に切り替えた Worker は新世代のまま。更新 Future の取消時に受付を再開する修正を追加。
- Cog の明示登録・型付き共有・ライフサイクル基礎と、`#[cog] impl` の引数なし command 自動登録を追加。型付き引数、イベントメソッド、Worker ライフサイクル統合は未実装。
- 不明な応答の一覧と、インスタンス ID・Worker 番号・操作 ID・照合根拠を要する明示解除の Manager API を追加。認証済み管理 IPC/CLI、監査の永続化は未接続。再起動で追跡は消える。
- 設定からローカル primary の起動意図を列挙する機能を追加。実プロセス起動、Identify と quorum/lease は未実装。
- 変更前後の Linux workspace fmt/clippy/test は通過。最後に追加した受付再開と照合 API は個別検証済み、全体再検証が必要。

## 継続：レビューと Identify
- 応答結果不明の解除 ID が Worker 間で衝突して誤解除される欠陥を修正し、プロセス内一意 ID と誤 Worker 指定の回帰試験を追加。認証済み管理経路、永続監査、根拠検証は未実装。Ready handler のエラー本文はログへ出さない。
- Cog の停止失敗・状態差替・名前衝突をテスト。prepare/abort/commit の独立した失敗時復旧契約を試作したが Cog や Worker 切替には未接続。
- Gateway メタデータ取得・検証と auto Shard 数解決、単一プロセスで Bot 単位に Twilight Identify キューを共有する基盤を追加。Gateway に未接続。別プロセスや再起動間の制限共有はなく、本番複数ノードの許可機構ではない。配置エラーから未信頼の ID を除き、ログ漏洩を防止。
- Linux fmt/clippy/workspace test は上記の Identify と配置ログ修正以前の状態で通過。これら追加後は個別テスト通過、全体再検証が必要。

## 継続：Gateway 初期化と引数基盤
- 単一 Shard Gateway 起動前に Discord Gateway 情報を取得・検証し、単一プロセス内の Identify キューへ接続。取得失敗は固定エラーで起動停止し、推奨 Shard 数が複数の場合は警告する。実 Discord と再起動間・複数プロセス間の Identify 窓は未検証・未調整。起動時に metadata 取得が必要となる。
- Prefix/Slash 相当の入力から String/i64/bool と末尾 Option を抽出し、フリー関数属性マクロに接続。実 Gateway/Worker、Cog メソッド、Discord 登録 schema は未接続で、型付きハイブリッド完成ではない。
- 認証済みローカル応答照会・解除の設計案を docs/local-response-management.md に追加。実装および永続監査は未完。
- Linux Rust 1.99.1: `cargo fmt --all`、workspace clippy（警告禁止）、workspace test が通過。実 Discord、Windows、複数ホスト・性能試験は未実施。

## main 統合時点
- 型付き Prefix / Slash の実 Worker IPC、Discord option schema 生成、登録要求への schema 接続を追加。実 Discord への登録・接続は未検証。
- 認証付き読み取り専用ローカル制御プロトコルを匿名ストリームで検証。実プロセス配線・bootstrap・監査・CLI は未実装。
- 配置・Identify キューのオフライン結合試験と Shard 実行設計書を追加。複数 Shard の実起動、分散 Identify・quorum/lease は未実装。
- 今後の優先順は実 IPC 管理と応答監査、Shard 単位の Gateway/Core 分離、Identify 制御と所有権、実 Discord・Windows・障害・性能検証。未検証部分を完成扱いしない。

## 2026-11-12：PM 主導の並列開発 第1弾（Codex CLI）
- 4作業を worktree 分離で Codex に実装させ、PM が検証・統合した。Codex のサンドボックスはネットワークと .git 書込みが使えず、cargo 検証とコミットは PM が代行。
- `ownership.rs`：OwnershipCoordinator trait、StandaloneCoordinator、ownership_epoch の単調増加と古い epoch の拒否、注入 Clock による lease/watchdog（失効後 fail closed）、QuorumCoordinator は起動拒否のみ（独自合意は実装しない）。再起動を跨ぐ epoch 永続化と実プロセス停止への接続は未実装。
- `shard_runtime.rs`：配置計画から Shard 単位の Gateway/Core 起動仕様（token は Gateway のみ、IPC/状態/管理パスを Bot/Shard 単位で分離）を生成。実プロセス起動には未接続。
- 認証付きローカル管理：`manage list-unknown`（読み取り専用）を匿名パイプ bootstrap で配線。解除操作・永続監査・ページ化は未実装、Windows ACL は未検証。
- framework Cog：Ready イベント自動登録、型付き引数、既定 drain フック。実 Worker/Gateway 接続は未実施。
- main 統合後、Linux ではなく Windows 上の Rust 1.99.0 で `cargo fmt --check`、workspace clippy（警告禁止）、workspace test が成功。Linux、Windows CI、実 Discord、複数ホスト、性能は未検証。

## 2026-11-12：並列開発 第2弾（Codex CLI）
- `protocol.rs`/`worker.rs`：双方向 Hello・バージョン範囲交渉・Bot/Shard/世代 identity 照合・必須/任意 capability 交渉を追加（T19 相当の統合試験、旧 v5 互換維持）。identity は demo 固定値で、実配置とは未接続。docs/ipc-protocol.md を追加。
- `failover.rs`：§5.4 の状態機械（注入 Clock、500ms/1.5s/3s/30s 設定可、Quorum 不可は Degraded、指数バックオフ）を単体試験10件で検証。ネットワーク・実プロセス・Ownership との接続は未実装。
- `redact.rs`/docs/security.md：秘密マスク、`Secret<T>`、現状の漏洩リスク調査。既存ログ経路への適用は未実施（修正案のみ）。
- `benches/ipc_codec.rs`/docs/benchmarks.md：JSON と MessagePack の codec を Windows 開発機で計測。Linux 本番性能の根拠ではなく、採用判断は保留。
- 統合時に、管理試験が操作IDの固定値（0）に依存し並列試験で不安定になり得る問題を、worker 番号の確認に修正。
- main 統合後、fmt、clippy（警告禁止）、workspace test が Windows / Rust 1.99.0 で成功。Linux、Windows CI、実 Discord、複数ホストは未検証。

## 2026-11-12：並列開発 第3弾（Codex CLI）
- docs：README、developer-guide、operator-guide、known-limitations を実コード基準で整備（掲載サンプルのコンパイル・実行、doctor、register dry-run を確認）。
- `botref.rs`：Bot の名前/完全ID/一意なID接頭辞の解決、名前のスラッグ安全性、名前とIDの曖昧衝突の拒否、token env・状態パス重複検査（純関数。CLI/daemon 未接続）。
- `event_seq.rs`：local_sequence、有限バッファ（件数・バイト上限、優先度別満杯拒否）、ACK 範囲、未 ACK 再配送、受信側の欠落/重複検出。受付 ACK と処理完了を型で区別。実 IPC・切替には未接続。
- Worker identity：`BOT_ID`/`SHARD_ID`/`TOTAL_SHARDS`/`GENERATION_ID` を handshake と Gateway に接続（未指定は従来の 0/0/1）。不一致拒否を統合試験。世代番号の永続化は未実装。
- main 統合後、fmt・clippy（警告禁止）・workspace test が Windows / Rust 1.99.0 で成功。Linux、CI、実 Discord、複数ホストは未検証。
- 次候補：event_seq を実 IPC に接続、failover/ownership の接続、daemon/botctl の骨格、Core 世代切替の統合、secret マスクの既存ログ経路への適用、Linux CI の実行確認。

## 2026-11-12：並列開発 第4弾（Codex CLI）
- event_seq を Worker IPC に接続：`event-seq-v1` capability 交渉時のみ Ready に連番、Worker が受付 ACK を返す。旧 Worker は従来形式。ACK 欠落/不正/timeout を可視化。切替時の未 ACK 再配送は未接続。
- `botctl`（オフライン骨格）：config validate / shards / ps と --json、token は env 名のみ表示。daemon 操作は『未実装』で異常終了。
- failover と ownership を接続：承認を OwnershipCoordinator 経由で取得し epoch を保持、fencing、lease 失効で Active 停止、T11〜T14 相当を模擬 Clock/Fake で試験。実プロセス・実ネットワーク・成熟した合意バックエンドは未接続。
- 秘密マスクを bin/*.rs、placement.rs 等に適用し回帰試験を追加。worker.rs/main.rs 側の未対応箇所は docs/security.md に行・修正案を記録（PM 後続対応）。
- 統合時に clippy（items_after_test_module）を機械修正。main で fmt・clippy・workspace test（157件）が Windows / Rust 1.99.0 で成功。
- 運用メモ：並列 worktree ごとの target が累計約70GBとなりディスク満杯が発生。完了済み worktree の target と古い検証用 target を削除して復旧。今後は統合後に都度削除する。

## 2026-11-12：並列開発 第5弾（Codex CLI、reasoning high）
- `docs/quorum-evaluation.md`/`experiments/quorum-spike`：openraft 0.9.26 を独立スパイクで評価（メモリ内3ノード、リーダー選出・1ノード停止継続・過半数喪失で書込み失敗・分断で少数側が epoch を進められないことを確認、初回ビルド約42秒）。結論は『条件付き継続、本番採用は保留』。Linux、永続化、認証付き通信、lease/watchdog/fencing 統合は未検証。メイン workspace には未組込み。
- `supervisor.rs`：TaskManager/Supervisor（所有者・親子追跡、取消、タイムアウト、再起動予算・バックオフ・サーキットブレーカー、段階 drain）。注入時計で30件。実 Worker/Cog/IPC には未接続。
- `state_store.rs`：非同期 StateStore（TTL・容量・スキーマ互換・CAS）、メモリ実装、MAC 検証付き 100 文字制限 custom_id、View/Modal 状態、drain 対応 wait。非永続。外部 DB・Subscription 配送は未実装。
- `testkit.rs`：障害注入（遅延・切断・途中切断・満杯・帯域・seed）と模擬 REST/Interaction（429/5xx/結果不明）、自己試験31件。実 Worker での T15 統合は未実施。
- `framework/examples`：ping・hybrid・cog_counter・cog_moderation の実行可能サンプルと統合試験17件、CI に examples ビルドを追加（GitHub Actions 実行は未確認）。ban は dry-run、on_message 相当は未対応と明記。
- `benches/ipc_roundtrip.rs`/docs/benchmarks.md：実 Worker IPC 往復 各10,000件・失敗0、p99 は並列度1/4/16 で 126.3/389.5/588.3 µs（Windows 開発機、1ms 目標との比較は Linux で要再測定）。
- main 統合後、fmt・clippy（警告禁止）・workspace test（269件）が Windows / Rust 1.99.0 で成功。

## 2026-11-12：並列開発 第6〜7弾（Codex CLI：Sol/Terra/Astra）
- 第6弾：Core ホットスワップ試験(T04/T05/T06/T19 実 Worker)、REST/Identify 予算(`rest_budget.rs`/`update_gate.rs`)、RBAC・監査(`rbac_audit.rs`)、worker 統合（秘密保護・TaskManager 接続・event_seq 再配送）、`daemon.rs`/`botd`、`gateway_switch.rs`（307状態・34,549遷移で単一 Active 検証）、`metrics.rs`（Prometheus 出力）。
- 統合時に、秘密マスクがエラー診断まで潰して試験が5件失敗。第7弾で、秘密のみマスクし診断（種別・原因・終了コード）を保持する設計に修正。さらに T04（5秒処理中の in-flight 応答、並行 drain）と T06（切替直後クラッシュの管理記録）の本体不備を修正し、#[ignore] を解除。
- 第7弾：`cluster.rs`（Transport/Peer 表/決定的模擬ネットワーク、試験専用の過半数 ACK、T10〜T14、1,555 イベント列と 128 seed×96 障害操作で二重 Active 違反なし。本番合意ではない）、botctl↔botd 接続（ps/status/inspect/shards/start/stop/restart、force は --yes 必須、update/rollback は未実装）、管理経路への RBAC・監査・metrics 適用（T20）、Gateway ローリング結合シミュレーション（T07〜T09）。
- 統合後の試験不安定要因を修正：fixture の rlib 選択が古い rlib で失敗（最新を選ぶよう修正）、log_redaction を RBAC 前提へ更新。
- 現状：main で fmt・clippy（警告禁止）・workspace test が Windows / Rust 1.99.0 で成功（545件、無視1件の手動ベンチ、2回連続）。未検証: Linux、GitHub Actions、実 Discord、複数ホスト・実ネットワーク、Windows ACL、本番合意（openraft は評価のみ）。
- 運用：Codex は Sol(high)/Terra(high)/Astra(max) を難易度で使い分け。

## 2026-11-12：並列開発 第8弾（Astra max / Terra high）
- botd E2E：明示的な模擬 Discord モード（本番既定は無効、token 不要）を追加。botd が Bot A の Shard 0/1 と Bot B の Shard 0 を別プロセスで起動し、Gateway ごとに Worker(Core) が起動、`/ping`・`!ping` 相当が同一ハンドラーを通り REST 結果が要求元 Worker に戻ること、Bot 間の token/状態/IPC 分離、一方の Gateway クラッシュ時に他 Shard 継続と botd 再起動、Shutdown 契約による graceful 停止と孤児ゼロを統合試験（18件）で確認。実 Discord は未接続。
- `tls_transport.rs`：Tokio TCP + rustls の mTLS Transport（証明書によるノード ID 照合、平文・未許可ノード・偽 CA・巨大フレーム・slowloris の拒否、loopback 既定、秘密鍵保護）。実 TCP 上で heartbeat 途絶による failover 判定を再現。証明書失効・ローテーション、本体配線、本番 quorum/lease 統合は未実装。
- framework コンポーネント経路：Button/Select/Modal を `custom_id` で名前空間付きハンドラーへルーティングする属性マクロ（重複検出）、2つの独立 Registry が同一ストアで処理する模擬 T16、`wait_for` の drain 時キャンセル型と永続 Subscription 型の区別。実 StateStore アダプタ・実 Worker 接続・Subscription 配送は未実装。
- 統合後 workspace test は 605 件成功。ただし統合直後の初回実行で hot_swap_scenarios の T04 が1度失敗し、再実行（単体3回・全体1回）では成功。再ビルド直後の負荷に依存するフレークの可能性があり、安定性要再確認。

## 2026-11-12：並列開発 第9弾（最終段）
- 試験安定化：T04 のフレーク原因は、fixture が rlib を更新日時で個別選択し、異なる feature 構成の Tokio を混在させること（`there is no reactor running`）と特定。Cargo の依存解決/JSON 成果物取得へ移行し、条件待ち・ポート競合排除などを実施。空の target で `cargo test --workspace` を10回連続成功（CPU 負荷6プロセス併走9回を含む）。当初の一過性失敗との原因同一性は元ログ未入手のため未確定。
- 複数 botd 分散 E2E：mTLS で接続した3 botd が、試験用過半数 ACK・lease watchdog・failover/failback で T10〜T14（閾値短縮）を実 Gateway プロセス（模擬 Discord）上で検証し、二重 Active 違反なし。本番利用不可（明示フラグと模擬 Discord を必須とする guard）。実 openraft・永続化・実ホスト間・OS suspend は未検証。
- ベンチ追加（Windows 開発機の参考値）：failover 検知（loopback mTLS、50回）Suspected p50/p95 1,504.6/1,513.3 ms、FailoverPending 3,008.7/3,014.7 ms、正常時の誤判定 0/100 観測。event_seq・TaskManager・metrics・StateStore も計測。3秒は検知目標で Discord 再接続を含まない。
- docs：`docs/conformance.md`（§16.2 と T01〜T20 の適合状況表）、README と各ガイド、known-limitations を最新化。
- main 統合後の workspace test は 647 件成功、失敗 0、無視 1（手動ベンチ）を2回連続確認。fmt・clippy（警告禁止）成功。いずれも Windows / Rust 1.99.0。

## 残課題（次段階）
Linux と GitHub Actions での実行確認、実 Discord での接続・登録・Interaction 応答・Identify 検証、実 openraft 組込みと永続ストレージ、Daemon↔Gateway/Core の実本番配線（Worker を Core 代替から Shard 単位 Core へ）、StateStore と framework コンポーネント経路の Worker 接続、update/rollback、証明書失効・ローテーション、Windows ACL、性能の Linux 再測定。

## 引き継ぎ
別環境への移行用に、方針・PM/Codex 並列の進め方・運用上の注意・残課題を [handoff.md](handoff.md) にまとめた（2026-11-12）。

## 2026-11-12：別環境（Rust 1.90.0 / Windows）での再検証と互換修正
- 新環境のツールチェインは Rust 1.90.0。`atomic_try_update`（`AtomicU64::try_update`）が未安定でビルド不可だったため、安定版の `fetch_update` に置換（`framework/examples/counter/mod.rs`、`src/worker.rs`）。
- clippy `nonminimal_bool` 3件（`src/daemon.rs` 2、`src/main.rs` 1）を同値の書き換えで修正。fmt・clippy（警告禁止）は成功。
- `cargo test --workspace --no-fail-fast`：642 成功、5 失敗、1 無視。
  - `compile_fail::command_diagnostics`：trybuild の期待出力（警告文言）が Rust 1.99 前提で、1.90 の出力と不一致。実装の不具合ではなく、スナップショットのツールチェイン依存。1.99 では成功の記録があるため期待値は変更していない。
  - `botctl_daemon` の4件：全体並列実行時のみ失敗。単独実行（同ファイル、2回連続）では 11 件すべて成功。負荷依存のフレークと推定、原因は未特定（要調査）。
- 未検証は従来どおり（Linux、GitHub Actions、実 Discord、複数ホスト）。

## 2026-11-12：並列開発 第10弾（Codex 0.167.2：Astra max / Sol / Terra）
- 運用：Codex CLI を 0.147.0→0.167.2 に更新（6.1 系・astra が旧版で拒否されたため）。`gpt-6.1-*` と `gpt-6-astra` が利用可能。openraft 0.9.26 を PM が `cargo add`（features: serde, storage-v2, generic-snapshot-data）で追加。
- flake：botctl_daemon のタイムアウト試験の固定 1.5 秒競合を条件待ち（試験側が許可するまで Gateway が終了しない）に変更。負荷下で複数回成功。元の4件失敗が同一原因だったかは未特定。
- `fs_perms.rs`：Unix は開いたハンドルで mode 0600/0700 を検査・設定。Windows ACL は未実装（`Unsupported`）。既存の秘密ファイル経路には未接続。
- `tls_transport.rs`：ノードID/シリアル失効、重複期間付きローテーション、原子的交換（試験23件）。CA 更新・CA/中間失効、ポリシー永続化・配布は未実装。
- framework↔StateStore：InteractionContext から MAC 検証付き状態の作成/取得/TTL/CAS/削除、Bot/Shard/名前空間分離、wait と Subscription の区別（試験18件、`framework/STATE_ADAPTER.md`）。trybuild の警告文言依存を除去。Worker 実接続は未実施。
- `update_rollback.rs`/botctl：`update|rollback --plan` は dry-run 既定（SHA-256 検証、Identify予算考慮の Shard 別計画、rollback 計画）。実更新は daemon 未接続で `--yes` でも拒否。
- Gateway/Core 配線：模擬 Discord 限定で認証付き IPC による Gateway 切替（Pause→Activate）、Bot 単位 Identify 予算共有、placement からの1 Shard 1 Core 起動（Core に token 非配布）を実プロセス試験で確認。本番既定は無効。切替後の自動 rollback、子再採用、無欠落は未保証。
- `raft_quorum`：openraft による epoch CAS、永続ストレージ（sync_all、破損検出、ロック）、Ownership trait 接続、メモリ transport（試験35件）。本番起動は明示フラグでも拒否。mTLS 接続・自動引継ぎ・leader 転送は未実装。
- main 統合後（Windows / Rust 1.90.0）：fmt・clippy（警告禁止）成功、`cargo test --workspace --no-fail-fast` 756 成功・失敗0・無視2。Linux、GitHub Actions、実 Discord、複数ホストは未検証。
- 第2波を起動：raftnet（Raft を mTLS 上へ）、wkstate（StateStore の Worker 接続）、updctl（update/rollback の制御経路）、cidocs（CI・Linux 手順・文書）。

## 2026-11-12：並列開発 第11〜13弾（Codex：Astra max / Sol / Terra）と現状
- 統合済み：Raft(mTLS) transport・leader 転送・fencing 付き引継ぎ・自動 failover/failback runtime（`raft_quorum*`、`cluster_runtime.rs`）、証明書の失効/ローテーション/CA 管理/方針永続化（`tls_transport.rs`、`cert_policy.rs`）、永続 Subscription/ジョブ（`subscription.rs`、`durable_jobs.rs`）、framework↔StateStore↔Worker 接続とファイル永続 StateStore、daemon 側 update/rollback（認可・監査・同一操作ID）、子プロセス自動復旧（`child_recovery.rs` を daemon/worker に接続）、ログ経路の秘密保護、メトリクスのフィード API（daemon 未接続）、ファイル権限（`fs_perms.rs`：Unix mode、Windows は icacls /save の SDDL 解析によるパス指定 API）、実 Discord 検証の準備（`discord_smoke`、docs/real-discord-verification.md）。
- CI：GitHub Actions を並列ジョブ化（fmt、clippy、test、examples+doctor、stable 互換）。Linux は全ジョブ成功。Windows は Raft snapshot 試験と ACL 試験がランナー固有でタイミング/環境依存し、修正を統合済み（Actions での再確認は未了）。
- Linux ベンチ（Actions ubuntu-latest、AMD EPYC 7763 4vCPU、共有ランナー）：IPC 往復 各10,000件失敗0、p99 は並列度1/4/16 で 115.5/258.1/973.6 µs、failover 検知 Suspected p50 1503.6 ms / FailoverPending p50 3003.1 ms。往復値であり仕様の片道 p99<1ms の直接測定ではない。本番性能の保証ではない。
- **未達（正直な記録）**：無停止更新の負荷試験（`tests/update_load.rs`、現在 `#[ignore]`、手動実行）は許容基準（欠落0・ACK3秒以内等）を満たさない。連続更新で欠落1、Gateway 切替で欠落4・ACK未着2・2回目の切替失敗、新 Worker クラッシュで ACK 最大4.6秒。修正は実行中（zdtfix）。
- 実行中：zdtfix（上記の修正）、raftwire（Raft runtime の botd 配線。既定無効・模擬 Discord のみ）。完了後は `ci-verify` ブランチで Actions 検証を先行し、main へは確認後に反映する。
- 範囲：実 Discord での検証（接続、Slash 登録、Interaction 3秒、Identify/Resume）はユーザーが実施する。手順は docs/real-discord-verification.md。それより前の手順（模擬環境での実装・試験と CI）を完成の範囲とする。
- 未検証のまま：実 Discord、複数ホストの実障害、OS suspend、本番での Raft 有効化（起動は拒否のまま）、Windows ACL のディレクトリ対応、メトリクスの daemon 接続、永続 Subscription/ジョブの Worker 接続。

## 2026-11-12 終了時点（Codex クオータ切れで中断）
- Codex の利用枠が尽きた（次回利用可能: 2026-11-18 18:17 頃）。以降の Codex 方針: Luna max の高速モードを主、Terra は medium、Astra は設計・最終チェックのみ（コスパ重視）。
- 中断した作業は WIP としてブランチに保全済み（origin に push 済み、いずれも未検証・main 未統合）：
  - `codex/zdtfix`：無停止更新の修正。4ケース中3つ（連続更新、Gateway 切替、旧 Worker クラッシュ）は欠落0・ACK 47ms 以内。残る『ハンドラー実行後・結果返却前のクラッシュ』は仕様上の限界（結果不明）。次は `tests/update_load.rs` を、(1) 厳格な通常テスト、(2) 結果不明の #[ignore] テスト、に分割してから main へ統合する（分割しないと CI が失敗する）。
  - `codex/raftwire`：Raft runtime の botd 配線（既定無効・模擬 Discord のみ）と 3 プロセス E2E。ほぼ実装済みで未検証。
  - `codex/finaldocs`：docs の最終整備（benchmarks, conformance, developer-guide, known-limitations, operator-guide, security を途中まで更新）。事実照合が未了。
- 要調査：Actions の手動 stress（suite=acl、repeat=5）で Ubuntu iteration 1 と Windows iteration 4 が失敗。Windows ACL の CI 差の修正が完全には効いていない可能性がある。ログ確認から始める。main の Windows テストの結果は未確認のまま。
- 再開手順：`gh run list` で Actions を確認 → 上記3ブランチを `ci-verify` 等で Actions 検証 → 問題なければ main へ統合。ローカルの重い全体試験は避け、Actions（ci.yml、stress.yml、bench.yml）で行う。

## 2026-11-13：Windows サポート外、CI の並列化、Codex クオータ切れ後の統合
- 決定：対応 OS は Linux（Ubuntu）のみ。Windows はサポート外（Windows 固有コードは残すが保証・CI 対象外）。AGENTS.md と docs/architecture.md を更新。
- CI：`ci.yml` を Ubuntu のみの並列構成に再編（fmt、clippy、test の 5 シャード、examples+doctor、集約の ci-ok）。`.github/scripts/test-shard.sh` が実測時間で試験を分割（新規テストは rest に自動で入る）。dev プロファイルの debug 情報を縮小。stable は週次/手動の `stable.yml` へ、`stress.yml` は Ubuntu のみ（`switch` スイートを追加）。結果：全ジョブ成功、最長経路 約 280 秒（以前は直列で約 11 分）。
- 試験の安定化：Raft の lease 試験とプロセス/ネットワーク試験の待ち時間上限を CI 向けに緩和。実プロセス統合試験（process シャード）は、バイナリごとに直列実行にして安定。並列実行で不安定になる根本原因は未特定（known-limitations.md に記録）。
- 統合：zdtfix（無停止更新：連続更新・Gateway 切替・旧 Worker クラッシュは基準を満たす。『ハンドラー実行後・結果返却前のクラッシュ』は仕様上の限界＝結果不明として `#[ignore]` の別試験に分離）、raftwire（Raft runtime を botd に配線、既定無効・模擬 Discord 限定）、メトリクスの daemon 接続（Identify 待ち・drain 時間・世代・欠落数のみ。failover/IPC往復/REST予算の送信元は未接続）、docs の最終整備。
- ツール：Codex は利用枠切れ（2026-11-18 18:17 頃まで）。Antigravity CLI（agy、ファイル編集のみ）と Claude Code のサブエージェント（モデル指定なし）で代替。Haiku は環境設定のため使えなかった（要 Claude Code 再起動後の再確認）。
- 未検証・未完了：実 Discord（ユーザー実施）、複数ホストの実障害、OS suspend、本番での Raft 有効化（起動拒否のまま）、メトリクスの残りの送信元の接続、永続 Subscription/ジョブの Worker 接続、Core 単独更新・更新失敗時の自動 rollback、process シャードの並列不安定の根本原因。

## 2026-11-14：不安定な統合試験の根本原因の解決と、Linux 常駐運用の整備
- **根本原因の解決（本番相当の競合）**：実プロセス統合試験が CI（Ubuntu、4 vCPU）で約 35% 失敗していた（20 回中 7 回）。診断（時間切れ時に botd の状態を出す）で、同じ Bot の複数 Shard が同時に起動すると、片方が `Degraded: IdentifyUnavailable` になり永久に停止することが判明。原因は `MockIdentifyScheduler::reserve` が、ロック取得前に採られた時刻を『逆行』としてエラーにしていたこと。時刻を単調に丸めて修正（`src/src/gateway_switch.rs`）、単体試験を追加。修正後 20/20 成功。実運用の共有 Identify 調整でも、時刻のサンプリングと直列化の順序に同じ落とし穴がある。
- 別の不安定さ（ETXTBSY）：試験が実行ファイルを `fs::copy` した直後に起動すると、同一プロセス内の他スレッドの fork が書き込み fd を保持している間に `Text file busy` で失敗し得る。`testkit::copy_executable`（ハードリンク、不可ならコピー）に置き換え（5 か所）。
- CI：`process` シャードを、直列・再実行の暫定対応から、並列・再実行なしに戻した（根拠：反復 stress で 20/20 と 20/20）。stress に `switch`/`process` スイートを追加。
- Linux 常駐運用：`deploy/systemd/botd.service`、`deploy/botd.env.example`、`docs/linux-deployment.md` を追加。botd に systemd `sd_notify`（READY/WATCHDOG/STOPPING、既定経路のみ）を実装（実 systemd では未検証のため unit では無効）。botd と botctl に `--secret-file`（権限 0600/0400、所有者、リンク拒否の検査）と `botctl secret generate` を追加し、systemd 常駐の botd を botctl で操作できるようにした（以前は secret を渡す手段がなく操作不能だった）。`--control-port` を追加。いずれも Ubuntu の CI（試験 5 シャード、clippy、fmt）で成功。実 Ubuntu/systemd の実機は未検証。
- 運用：Haiku は Claude Code の再起動後に使えるようになった（軽い読み取り作業向け。余計なツールを呼ぶことがあるので範囲を絞る）。サブエージェントのローカル cargo は PC 負荷のため禁止し、検証は Actions で行う。
- 未検証・未完了：実 Discord（ユーザー実施）、実 systemd/Ubuntu、複数ホストの実障害、本番での Raft 有効化（起動拒否のまま）、メトリクスの残りの送信元（failover、IPC 往復、REST 予算）、永続 Subscription/ジョブの Worker 接続、Core 単独更新・更新失敗時の自動 rollback、`raft_botd_processes` の rejoin の稀な失敗（原因未特定、診断を強化済み）。

## 2026-11-14（続き）：実 systemd での検証
- `.github/workflows/systemd-smoke.yml`（`deploy/**` や botd/botctl の変更で自動実行、手動実行も可）で、GitHub のランナー（Ubuntu）の実 systemd 上に botd を導入して検証。確認できたこと：unit の構文（`systemd-analyze verify`）、`Type=notify` で `READY=1` が届き起動が完了すること、`WatchdogSec=6s` の周期を超えて再起動 0 で動き続けること、`--secret-file` + botctl の `status` が通り別 secret は拒否されること、`systemctl stop` で正常終了（Result=success）すること、Gateway と Core ワーカー 2 つが systemd 配下で起動し稼働すること（模擬 Discord、外部への接続なし）。
- unit の硬化を追加し（`SystemCallFilter=@system-service`、`~@privileged @resources`、`ProtectProc=invisible`、`ProcSubset=pid`、`RemoveIPC`、`ProtectClock`、`ProtectKernelLogs`、`ProtectHostname`、`RestrictRealtime`、`SystemCallArchitectures=native`）、硬化なしのベースラインと並べて、どちらも Gateway と Core が起動・稼働することを確認。
- 発見（運用上の落とし穴）：同梱の Gateway（`src`）は `--bot-id` が正規の 10 進 u64 でないと `launch_invalid` で即終了し、botd は子が起動のたびに落ちて再起動を繰り返す。botd は事前に検出しない（`--gateway-program` は差し替え可能で、試験用フィクスチャは文字列 ID を使うため。一律の事前検証は試験を壊すので取り消した）。docs/linux-deployment.md に症状と確認方法を明記。子の標準エラーは botd が破棄するため journald に出ない（既知の制約）。
- smoke の初期版は `--no-autostart` で子を起動しておらず、Gateway の失敗を見逃していた。判定を『Running・再起動 0・Core ワーカー 2』に直して、子の起動まで検証する形にした。
- 未検証：実 Discord、実機の systemd（ランナー外）、systemd 配下で Type=notify を既定にすること（unit では無効のまま。有効化は上記 smoke の drop-in で確認済みだが、出荷する unit の既定は Type=simple）。

## 2026-11-14（続き）：実 Discord での初回検証（ユーザー実施、成功）
- 環境：Oracle Cloud の Ubuntu、ユーザー自身のテスト用 Bot とテストギルド。手順は docs/real-discord-verification.md の「最初の 30 分」。
- 結果：(1) `botctl config validate` が成功。(2) `discord_smoke --apply`（読み取り専用）で `gateway_bot`・`current_user` がともに成功し、レート制限ヘッダも正常。(3) `register`（ギルド限定、dry-run→`--apply`）で `ping` を登録。(4) Gateway を単体起動して `ログイン成功`、`/ping` と `!ping` の両方で `Pong! 🦀` が返った（Message Content Intent を有効化済み）。(5) botd 経由で起動し、`botctl status` で `Running`・再起動 0、`botctl stop` が 50ms で成功（`Exited` code 0、`restarts` 0、`startup_failures` 0）、Gateway 子プロセスが残らないことを確認。
- 実機で分かったこと：開発 PC のフォルダをコピーすると、`.gitignore` 対象の `worker-path.txt`（Windows のパス）と `workers/`（Windows の実行ファイル）が入り、Linux で `Workerのパスは絶対パスにしてください` が 2 秒ごとに出る（無害）。サーバには `git clone` で取得するか、これらを除く。`bots.toml` の `bot_id` は、botd 内の識別番号（数字）で、Discord の Bot の ID とは別（実際の ID は token から決まる）。
- 検証していないこと：応答時間の計測値、長時間稼働、Resume、複数 Shard、レート制限が実際に出る場面、systemd 常駐での実 Discord 接続。


## 2026-11-14（続き）：実機検証を受けた改善（CI 検証済み、実 Discord では未確認）
- botd：Gateway 子の stdout/stderr を、Shard ごとの状態ディレクトリの `gateway.log`（0600、1 MiB 超で `gateway.log.1` へ 1 世代ローテーション、リンクや通常ファイル以外は従来どおり null）に残す。botd 経由でも、接続失敗の理由（close code など）が見える。
- Gateway の応答経路（`main.rs` の live 経路）：全送信で `allowed_mentions` を無効化（`@everyone` の防止）、返信を 2000 文字にクランプ（`clamp_reply`、空は固定文言）、同時 64 件超・未リンクのコマンド・channel なしの場合に ephemeral の短い応答を返す、Interaction の ACK（defer）を先に送ってから応答の配信開始（`begin_response_delivery`）を待つ順序に変更（M1）。
- 検証：CI（Ubuntu、clippy・試験 5 シャード・fmt）は成功。ただし統合試験は live 経路（`main.rs`）を通らないため、**実 Discord での再確認が必要**（特に M1 の順序変更）。再確認の手順は docs/real-discord-verification.md の 3.5・4・5。

## 2026-11-14（続き）：改善版の実機再確認（ユーザー実施、成功）
- 同じサーバ（Oracle Cloud の Ubuntu）、同じテスト用 Bot で、ソースのアーカイブ（`git archive`、約 1MB）を展開してビルド。(1) Gateway を単体起動して `ログイン成功`、`/ping` と `!ping` が返る、`Workerのパス…` の警告は出ない（Windows 由来のファイルを含まないため）。(2) botd 経由で起動し、`state: Running`、`restarts: 0`、`startup_failures: 0`。`gateway.log`（0600、`--- gateway generation 1 ---` と `ログイン成功` を含む）が Shard ディレクトリにできた。`/ping` と `!ping` が返った。
- 実機で出た問題と原因：(a) `bots.toml` を移動したため `cannot load daemon configuration`（ファイルのパス違い）。(b) botd を起動した端末に、`token_env` の名前（`DISCORD_TEST_BOT_TOKEN`）で token を設定していなかったため `MissingCredential`・`state: Failed`・`restart_exhausted: true`（`gateway.log` は子の起動前の失敗のため作られない）。手順書の例の名前が実際の `token_env` と食い違っていたことが混乱の元だったので、手順書に明記した。
- botd の停止順序：botd だけを `Ctrl+C` で止めると、Gateway とワーカーが残り（既知の設計）、起動予約ファイルも残る。`botctl stop` を先に実行する順序を手順書に明記し、残った場合の手順（kill と予約ファイルの削除）を追記した。
- 検証していないこと：応答時間の計測値、長時間稼働、Resume、複数 Shard、systemd 常駐での実 Discord 接続、レート制限が実際に出る場面。
- 改善候補（未着手）：botd が終了時に、自分が起動した子を、確認つきで停止する（または `botctl shutdown` のような一括停止）。現状は、手動運用で停止順序を守る必要がある。


## ロードマップ：Gateway の無停止更新（ローリング）の本番化（未着手、2026-11-14 に合意）
- 現状：模擬 Discord の試験モードのみ（状態機械、旧 Gateway の drain、単一 Active、共有 Identify 予算を実プロセス試験で確認）。通常の daemon では実更新を安全に拒否する。Core（Worker）のホットスワップは標準経路で使える。
- 本番化に必要：(1) 旧 Gateway から新 Gateway への Discord セッション（session_id、シーケンス番号、resume_gateway_url）の保護された引き継ぎと、新 Gateway の Resume（新規 Identify を消費しない）。(2) 複数プロセス間の Identify 調整（現状はプロセス内のみ）。(3) 実 Discord での検証（Resume の成否、切替中のイベント欠落、Interaction の 3 秒）。
- 進め方：設計は Astra（max）、実装は Luna（max、高速）、検証は stress ワークフローと実機。Codex の利用再開（2026-11-18 18:17 頃）後に着手する。

## 2026-11-14（続き）：手元の WSL2（Ubuntu 24.04、systemd 動作）での実 systemd 確認
- `deploy/dev/wsl-systemd-smoke.sh` を追加（Actions の `systemd-smoke.yml` と同じ内容を手元で繰り返せる）。WSL に build-essential・pkg-config・jq と Rust 1.90.0 を導入（ユーザー許可のうえ、`wsl -u root` で apt。Rust は一般ユーザー）。release ビルドは `-j 8` で 1 分 20 秒。
- 結果（main 69f7f74、模擬 Discord）：unit の起動（Type=notify、Watchdog）、Core ワーカーの `kill -9`（補充、Gateway は不変）、Gateway の `kill -9`（再起動）、botd の `kill -9`（systemd が再起動、`NRestarts=1`、予約が整理され Gateway が復帰）、`systemctl stop`（`Result=success`、残りプロセス 0）がすべて成功。後片付け（専用ユーザー・/etc・/opt・/var/lib・unit・プロセス）が残らないことを確認。


## 2026-11-14 終了時点の状態と、次回の再開手順
- **main（検証済み）**: cd4bfb7。CI（Ubuntu）全ジョブ成功、実 systemd smoke（自動復旧を含む）成功、実 Discord の基本動作（ログイン、`/ping`、`!ping`、`!count`、ワーカーの `kill -9` 復旧、`botctl stop`）は、ユーザーのサーバと WSL で確認済み。
- **実機（WSL2 Ubuntu 24.04）**: botd は停止済み（`systemctl stop botd`、`Result=success`、残りプロセス 0）。unit、`/etc/discord-rs/{botd.env,botd.secret,bots.toml}`、`/opt/discord-rs/bin`、専用ユーザー `discord-rs` は残してある（token は `/etc/discord-rs/botd.env`、0640。値は誰にも見せていない）。再開は `sudo systemctl start botd`。不要になれば `userdel discord-rs; rm -rf /etc/discord-rs /opt/discord-rs /var/lib/discord-rs /etc/systemd/system/botd.service`。
- **実機で見つかった未解決（修正中）**: (1) 実 Discord では Gateway の `kill -9` から自動復旧しない（`try_acquire_identify` が実 Discord の自動復旧を意図的に拒否）。(2) Gateway/botd の再起動で `!count` が 0 に戻る（Core が Gateway の子で、状態が Gateway のメモリ上。設計上の Gateway/Core 分離が通常経路では未実装）。
- **未マージの作業**:
  - ブランチ `wip/identify-merge`（70ee9f5）: (1) の修正（ローカルの Identify 許可: 最短 30 秒間隔・1 時間 10 回。`src/src/local_identify.rs`、`daemon.rs`）。`ci-verify` で CI と systemd smoke を実行中。緑なら main に反映し、WSL で再度 Gateway の `kill -9` を試験する（Identify を 1 回消費）。
  - サブエージェントの作業ツリー `.claude/worktrees/agent-accc796218e0e2c02`（未コミットの可能性）: Core の確認済みスナップショット（count/job）の永続化（`src/src/core_state.rs`、`worker.rs`）。
  - サブエージェントの作業ツリー `.claude/worktrees/agent-a8a6c25f16f001e16`: Gateway と Core の分離の設計書（`docs/gateway-core-separation-design.md`）。
  - 上の 2 つは、完了時にコミットされる想定。作業ツリーに未コミットの変更が残っていれば、内容を確認してから取り込む。
- **次にやること（優先順）**: (a) `wip/identify-merge` の CI 結果を確認して main に反映 → WSL で Gateway の `kill -9` を再試験。(b) 永続化のブランチを取り込み、WSL でビルド・対象試験 → CI → 実機で `!count` が再起動後も続くか確認。(c) 設計書を読み、Gateway と Core の分離を段階実装（実装の主体は Claude とサブエージェント。Codex は Plus で 5 時間制限のため補助のみ）。(d) Gateway の無停止更新（セッション引き継ぎと Resume）は分離の後。

### 追記（終了直前）
- 永続化のサブエージェントが完了: ブランチ `worktree-agent-accc796218e0e2c02`（ac1588b、`src/src/core_state.rs` ほか。保存は約 0.5 秒ごとに変化を検知し最短 2 秒間隔、停止時に必ず保存、起動時に復元。イベントのジャーナル・カーソルは保存せず、`kill -9` では最大約 2.5 秒分が失われる）。
- Identify 許可と永続化を合わせた版を `wip/combined`（origin に push 済み）で CI 実行中。**この版は main に未反映。CI が全ジョブ緑になったら main に反映し、WSL で Gateway の `kill -9` と、再起動後の `!count` 継続を実機で確認する。**
- 設計書のサブエージェント（`docs/gateway-core-separation-design.md`）は作業中。完了していれば `worktree-agent-a8a6c25f16f001e16` に出る。

### 訂正（終了直後）
- Gateway と Core の分離の設計書は、サブエージェントが停止され、**未作成**（成果物なし）。次回、あらためて作成する（読み取り調査 → `docs/gateway-core-separation-design.md`）。上の『作業中』の記述は、この訂正を正とする。

## 2026-11-15：実 Discord・実 systemd での常駐・自動復旧・Core の無停止更新の実機確認（成功）
- 環境：WSL2 の Ubuntu 24.04（systemd）、ユーザーのテスト用 Bot、main 1ad8daa（Identify のローカル許可と Core 状態の永続化を含む）。unit は出荷版（`--stop-children-on-exit`）、token は `/etc/discord-rs/botd.env`（0640）。
- 結果（すべて実 Discord）：(1) 常駐の起動：`ログイン成功`、`/ping`・`!ping`・`!count` が返る。(2) Gateway を `kill -9`：**2 秒で自動復旧**（`restarts: 1`、`--- gateway generation 2 ---` で再ログイン）。前日は `Failed`・`restart_exhausted: true` で復旧しなかった。(3) 復旧後の `!count`：3 → **4**（Core の確認済みスナップショットの永続化が Gateway の再起動をまたいで働いた）。(4) botd を `kill -9`：**6 秒で systemd が再起動**（`NRestarts=1`）、`daemon: removed stale launch reservation (no live Gateway)` で古い予約が整理され、Gateway が復帰。`!count` は **5**。(5) Core（Worker）の無停止更新：`worker-path.txt` に新しい実行ファイルのパスを書くと、**Gateway の PID は不変のまま** 2 秒で Worker が 2 つとも入れ替わり（`Worker 1/2 を切り替えました`、`Worker 2/2 を切り替えました`）、`!count` は **6**。(6) `systemctl stop`：0 秒で `Result=success`、子も含め残りプロセス 0、起動予約 0、`core-state.json` は残る。
- 実機で分かった WSL の注意：WSL2 はアイドルで VM ごと停止する（約 25 秒）。**開いた端末（セッション）がないと botd が道連れで止まる**。実験中は WSL の端末を開いたままにする（または `.wslconfig` の `vmIdleTimeout`）。バックグラウンドの `wsl.exe -- sleep` では維持できなかった。
- 未検証：WSL の再起動後の botd の自動起動（`systemctl enable` していない）、長時間稼働、Resume、複数 Shard、レート制限の実機、Gateway の無停止更新（ローリング）、Gateway と Core の分離（通常経路は未実装。ロードマップ）。
- 修正済みの課題：実 Discord の Gateway 自動復旧（ローカルの Identify 許可：30 秒間隔・1 時間 10 回）、再起動をまたぐ `!count` の維持（確認済みスナップショットの永続化。イベントのジャーナルとカーソルは保存せず、`kill -9` では最大約 2.5 秒分が失われる）。

## 2026-11-15：Gateway と Core の分離（設計書の取り込みと方針決定）
- 設計書 `docs/gateway-core-separation-design.md` を取り込み。要点：試験用モードでも Core は Gateway の子（匿名パイプ）で、分離には IPC の媒体の改修（Unix socket、Core 側の受け入れ、接続ごとの状態初期化）が要る。生きている Core に再接続する Gateway は `core-state.json` で状態を巻き戻してはならない（鮮度判定が必須）。分離は単独で障害耐性を大きく上げず、価値は Gateway の無停止更新（新旧 Gateway が同じ Core を共有）の前提になる点。
- 方針（ユーザー決定）：Gateway の無停止更新を目標に分離を進める。第 1 段階は opt-in の `botd --core-mode separate`（Linux、Unix socket、既定は従来のまま、Core 先・Gateway 後）。判断点は設計書の推奨を採用（旧経路は検証完了まで維持、Core は N プロセス `ChildKey.slot`、ホットスワップは後回し、botd 死亡時は Core も失う、IPC 認証は既存方針、Core の成果物は `src --worker` と同一）。

## 2026-11-15：分離の 1-B（Core のソケット受け入れと接続型 attach）
- 1-B1：`--core-listen`（Unix ソケット、0700 ディレクトリ・0600 ソケット・SO_PEERCRED・stdin の 64 桁 16 進秘密を定数時間比較）。1-B2a：`Process::attach`。1-B2b-i：`Manager::attach_gateway_pool`（子を起動せず、Core の復旧・永続状態の Restore もしない。shutdown は Core を止めない）。いずれも CI 緑（process シャードの `core_attach`）。
- 1-B3：Core のアプリケーション状態を `CoreLife` に分け、`serve_connection` が接続ごとの交渉状態（capabilities・保留中の API 結果・イベントカーソル・drain）を作り直す。接続が失敗しても状態は Core に戻る。`core_server::serve` に `Lifetime::{OneConnection, UntilStopped}`。`run`（`--core-listen`）は従来どおり `OneConnection`。`UntilStopped` を botd が使う配線は未実装。
- 検証：WSL で `core_attach` 9 件成功（持続 Core が 3 接続を処理し不正秘密の接続で止まらない／`OneConnection` は 1 接続で終了）。CI は 70ab7ec で `a_stale_socket_is_replaced…` が 1 回 Connection refused で失敗したが、同じテストを WSL で 40 回回しても再現せず、テストのみ変更（Core の stderr を CI ログに出す）の再実行は成功した。**原因未特定の不安定要因として残す**（再発時は Core の stderr で確認）。最後の試験追加コミット（722eda0）の CI は未確認。
- 状態の保持そのもの（再接続後に `!count` が残る等）は構造上のもので、試験では未確認。
- 次：1-B2b-ii（切断検知と上限付き再接続）、1-B2c（`core-state.json` の鮮度判定）、1-C（botd の `--core-mode separate`）。
- 1-B2b-ii：attach した Manager は、接続が壊れたスロット（`process.broken`）を上限付き指数バックオフ（100 ms〜5 s）で再接続する（`poll_core_reconnect`）。子の起動はしない。再接続した Core へは `core-state.json` を Restore しない（Core 自身の状態を正とする）。`--core-listen <path> --core-persist` で接続をまたいで動く Core を起動できる（試験・1-C 用）。試験：Manager を作り直しても `!count` が続く、落ちて起動し直された Core へ再接続して処理が続く。CI 緑（fmt 修正後、3m48s）。
- 制約：切断の検知は次の要求の失敗時（待機中の切断は能動的には検知しない）。再接続後のイベントカーソル／未確認イベントの再送、`core-state.json` の鮮度判定（1-B2c）は未実装。前回 CI の `a_stale_socket…` 失敗は再発していない。
- 1-B2c：attach した Manager は、起動中の Core の状態を `core-state.json` で巻き戻さない。`prepare` が採用する Core 自身のスナップショットを正とし、永続化された状態（起動時）／最後に確認した状態（再接続時）は、Core の確認済みスナップショットが空の初期状態と一致する場合（= botd が起動し直した空の Core）にだけ Restore する（`Process::core_is_fresh`）。attach した Manager も状態を永続化する。試験：古いファイルが生きた Core に入らない、起動し直された Core に最後の状態が入る。
- 不安定要因の原因（解消）：`a_stale_socket_is_replaced…` の失敗は製品の欠陥ではなく試験側の競合だった。試験が listen 中の古いソケットを作ると、別テストが同時に子を fork した間、その子が fd を引き継いで古いリスナーが生き残り、準備確認の接続が古いソケットに成功して、後で RST になる（WSL で並列 8×40 回の実行で再現、修正後 0/320）。古いソケットはデータグラムの bind で作る方式に変更。
- 1-C（途中・未検証・未 push）：`core_attach.rs`（Core ディレクトリ・secret・identity の共有規約）、`core_units.rs`（botd による Core の起動・バックオフ再起動・stdin を閉じて停止、Core は stdin の EOF で終了）、Gateway の `--core-dir`（attach、ホットスワップ監視は無効）を追加。cargo check のみ通過。**未配線**：Daemon への組み込み（launch で ensure、poll で再起動、shutdown_children で Gateway の後に停止）、botd `--core-mode`、Process::attach の接続リトライ（Core 起動待ち）、E2E 試験、CI。
- 1-C（配線完了・CI 確認中）：Daemon に `enable_separate_cores`／起動時に Core → Gateway の順（`--core-dir` を Gateway に付与）／poll で Core の再起動（1 s〜30 s のバックオフ）／`shutdown_children` の最後に `stop_cores`、botd に `--core-mode embedded|separate`（separate は `--stop-children-on-exit` 必須）。`Process::attach` は起動中の Core を最大 3 s 待つ。実プロセス試験 `botd_separate_cores`（WSL で成功）：Core は Gateway の子でなく、Gateway クラッシュ後も同じ Core の PID に再接続、Core 1 本の `kill -9` で botd がその Core だけ再起動し Gateway の PID は不変、botd の SIGTERM で Gateway・Core が全停止しソケット／secret が残らない。未実施：Core 2 本同時の kill、切断中の入力拒否の確認、実 Discord・systemd での確認、`botctl status` への Core 表示、`core-state` が Gateway 再起動後も Core 側に残ることの E2E（`core_attach` の単体では確認済み）。
- 1-D（status・smoke・docs）：status の各 Shard 行に、separate のときだけ `cores`（running/failures）を追加。systemd smoke に separate の手順を追加し、Actions の実 systemd で成功（Core 2 本の親が botd、Gateway を `kill -9` しても Core の PID 不変、`systemctl stop` で Gateway・Core・sock・secret が残らない）。docs（known-limitations / shard-runtime-design / operator-guide / ipc-protocol）を更新。
- 不安定要因（原因未特定）：同じコミットの Rust CI で `update_load` の `crash_old_core`（embedded の Core クラッシュ負荷試験）が 1 回失敗し、再実行で成功した。今回の変更は embedded の経路に触れていないが、再発するまで原因は不明。
- 分離の第 1 段階（1-A〜1-D）は実装・CI 検証済み。実機（WSL・実 Discord）での確認項目は設計書 §5.4 のとおり未実施。

## 2026-11-15：分離（`botd --core-mode separate`）の実機確認（WSL2 の実 systemd、実 Discord、成功）
- 環境：WSL2 Ubuntu 24.04（systemd）、テスト用 Bot、Shard 1、main 0703cf1 のリリースビルド。drop-in `zz-separate.conf` で `--core-mode separate` を有効化（`docs/real-separate-verification.md`）。
- 結果（すべて実 Discord。`!count` は 10 から開始）：(1) 起動：ログイン成功。Core 2 本の親は botd、Gateway も botd の子（`--core-dir` で attach）。ipc のソケット・secret は 0600、ディレクトリは 0700、`botctl status` に `cores` が出る。(2) Gateway `kill -9`：**1.3 秒で新 Gateway が起動**し再ログイン、**Core の PID は不変**、`!count` は 10→**11**（巻き戻りなし）。(3) Core 1 本 `kill -9`：botd が **1.1 秒でその Core だけ再起動**、**Gateway の PID は不変**、`!count` は **12**。(4) Core 2 本とも `kill -9`：両方再起動、Gateway は不変（`BrokenPipe` を検知して記録）、直後の最初の `!count` が **13** で成功（無反応なし）。(5) `systemctl stop`：0.07 秒、`Result=success`、残りプロセス 0、ipc の sock・secret なし、起動予約なし、`core-state.json` は残る。(6) botd `kill -9`：**5.2 秒で systemd が再起動**（`NRestarts=1`）、Gateway・Core とも入れ替わり孤児なし、`!count` は **14**。
- 分かったこと：期待どおりに動いた。Gateway の再起動時間は、embedded の約 2 秒（前回の記録）より短かった（Core の再起動を含まないため）。(4) で `!count` が失われなかったのは、Gateway が保持する確認済みスナップショットが空の新 Core に戻されたため。
- 未確認のまま：長時間稼働、複数 Shard、Resume、レート制限、OS 再起動後の自動起動、Core のホットスワップ（separate では未対応）、(4) の切断中に入力が来た場合の拒否の数（今回は入力なし）。

## 2026-11-15：Gateway の無停止更新の設計案
- `docs/gateway-rolling-update-design.md` を追加（設計案、未実装）。第一候補は Resume ではなく「二重セッション＋待機側のバッファ」（新 Gateway が別セッションで Identify→Standby→Pause/epoch 切替→Active。session_id の引き渡しが不要）。必要な変更：Core の同時 2 接続と epoch による fencing、接続時 identity、候補 Gateway の `--standby`、botd の本番経路。実 Discord での V1（同一 Shard の 2 セッション）が方式を決めるため、実装前に先に確認する案。
- V1（実 Discord、WSL、2026-11-15）：同じ Bot・同じ Shard（1/1）に、botd 配下の Gateway A と、別の状態ディレクトリで手動起動した Gateway B を同時にログインさせ、`!count` を 1 回送ったところ、**2 件の返信**（A の 15、B の 1）が返った。結論：Discord は同じ Shard の 2 つの Identify セッションを同時に有効にし、**両方にイベントが届く**（二重セッション方式の前提は成立）。A の接続は B のログイン後も切れなかった（ログに再接続なし）。B は試験後に停止・削除済み。未確認：2 セッションが長時間共存できるか、Identify の消費数（`session_start_limit` の残りは未記録）、切替中のイベント欠落・重複（V3）、Interaction の 3 秒（V4）。
- R-1（Gateway 無停止更新の第 1 段、Core のみ）：持続 Core は、1 つの接続を提供中でも次の接続を受け付けて認証し、attach 行に付けた epoch（`<64 桁 hex>[ <epoch>]`、無指定は 0）で順序づける。**高い epoch は提供中の接続を止め（要求と要求の間でだけ止まる。途中では止めない）、次に提供される。同じ epoch は順番を待つ。低い epoch は即座に拒否。** acceptor は 1 つの future を保持し、認証の途中のクライアントを失わない（最初の実装は select で future を落として負荷時に接続を失い、30×6 回の反復で見つけて修正）。`Fence`/`next_request` を worker.rs に追加。試験 `connections_are_ordered_by_ownership_epoch` ほか（core_attach 15 件、WSL で 30×6 回反復 0 失敗、clippy 緑）。**未実装**：Gateway 側が epoch を送る配線（今は Process::attach は epoch 0 固定）と Hello の identity による検証（R-2）、待機側の読み取り専用化（R-3）。
- R-2：Gateway が ownership epoch を attach 行（` <epoch>`、0 のときは付けない）と Hello の identity で提示する。Core は、epoch 付きで受けた接続の identity をその epoch に揃え、Hello の完全一致で検証する。Gateway の新オプション `--core-epoch N`（`--core-dir` と併用のみ、0 は不可）、`core_attach::load` が epoch を受ける。試験 `a_gateway_with_a_higher_epoch_takes_over_and_the_old_one_cannot_return`：epoch 5 の Manager が epoch 3 の Manager を引き継ぎ、`!count` が続き、古い方は要求が通らず再接続でも取り戻せない。botd からの epoch の採番（`--core-epoch` を渡す）は R-4。
- R-3a（重複排除、方式 (b)）：`Request::Dispatch` に任意の `source_id`（Discord のメッセージ ID。`serde(default, skip_serializing_if)` で後方互換）を追加。Core は直近 4096 件の ID の窓（`SeenIds`、Core の寿命で保持し接続をまたぐ。永続化しない）を持ち、既出の ID は処理せず「内容なし・状態不変」の結果を返す。Gateway のメッセージ経路は `message.id` を渡す（`Manager::dispatch_key_with_response_id`）。試験：同じ接続での再送、別 ID／ID なしは処理、引き継いだ別の Gateway（高い epoch）が同じ ID を配送しても処理しない、重複は状態を進めない。**未実装**：スラッシュコマンド／Interaction／コンポーネントの ID による排除（現状は重複し得る。Interaction の ID を載せる変更が別途要る）、Core 再起動をまたぐ重複の検知、`--standby` と `Activate`（R-3b）。
- `register --check`（スラッシュコマンドの変更検知）：Discord が持つコマンドを 1 回読み取り（書き込みなし）、リンク済みの定義（説明と引数の名前・型・必須）と比べて `status=up-to-date|changed|missing` を出す（要登録のとき終了コード 2）。`--apply` も先に同じ比較をし、最新なら何も送らない（コマンド作成の厳しいレート制限を無駄に使わない）。読み取りに失敗した `--apply` は従来どおり登録に進み、`--check` は失敗にする。比較は単体試験（Discord が足すフィールドを無視、説明・引数・必須の変更を検知）。実 Discord で `--check` を読み取り専用で実行し、グローバルの `ping` が `missing`（ギルド単位で登録しているため）と返ることを確認。未実装：全コマンドの一括同期、起動時の自動チェック。
- R-3b（待機 Gateway）：`--standby`（`--core-dir` 必須、`--core-epoch`・mock・local-control と併用不可）。Discord に自分のセッションでログインしてイベントを最大 512 件保留（超えたら中止）し、Core には接続しない。stdin の `{"command":"activate","epoch":N}`（`GatewayControl::Activate`）で `epoch N` の attach → 保留分を先に処理 → 通常動作。stdin の制御入力を連続読みに変更（`control_input`）。
- **実機（WSL、実 Discord、手動起動の待機 B と botd 配下の A）**：待機中に `!count` を 1 回 → A だけが返信（17）。B を `activate epoch 1` → 「保留 24 件」を処理して有効化。A のログは `worker is unavailable`（Core の接続を B に取られ、epoch 0 では再接続できない）。直後の `!count` は **B だけが 1 件**返信（18）。ユーザー報告は「18 が 1 件だけ」で、有効化直後の 17 の再返信が無いことは、個別の言及がないが報告の内容と矛盾しない（重複排除が効いた可能性が高い。保留分に 17 のメッセージが含まれていたかのログ上の裏付けは取っていない）。試験後、B を停止し botd を再起動して元に戻した。
- 未確認：重複排除が実際に働いた回数の計測、切替の所要時間、更新中に連続して送った場合の欠落、Interaction（スラッシュ）の重複。**botd が更新を指揮する経路（R-4）は未実装**で、今回の切替は手動。
- R-4（botd が Gateway の無停止更新を指揮）：`botctl gateway-update <bot>`（`--core-mode separate` のときだけ有効。embedded／通常の daemon は従来どおり安全に拒否）。新しいバイナリを Gateway のプログラムのパスに置いてから実行する。Shard ごとに順に：待機 Gateway（`--standby`）を同じパスから起動 → ログイン完了（`standby-ready` マーカー）を最大 90 秒待つ → `activate`（epoch+1）を送る → `ChildRecovery::replace_ready` で監督を新 Gateway に移す → 旧 Gateway に shutdown を送り、30 秒で終了しなければ kill（botd がハンドルを保持）。最初の失敗で中止し、稼働中の Gateway には触れない。更新後に botd が Gateway を再起動するときは `--core-epoch <現在の epoch>` を渡す（低い epoch では Core に入れない）。
- **実機（WSL、実 Discord、separate）**：(1) 更新（epoch 1）：operation `succeeded`、Core の PID 不変、旧 Gateway は終了、`!count` は 17→18→19 と **1 件ずつ**（保留 2 件）。(2) 更新後の Gateway を `kill -9`：botd が `--core-epoch 1` で再起動し attach 成功、`!count` 20。(3) 2 回目の更新（epoch 2、約 1.4 秒）：成功、`!count` 21 が 1 件。途中、手動試験の別ディレクトリで保存した 18 が botd 再起動で 17 に戻って見えたが、更新とは無関係（試験の後始末による）。
- 未確認：更新中に連続して送った場合の欠落・重複の実測（V3）、Interaction（スラッシュ）の重複排除と 3 秒（V4）、`session_start_limit` の消費、複数 Shard、長時間、候補のログイン失敗時の実機（単体でも未試験）、更新と並行した Core の再起動。`botctl gateway-update` は botd の通常の認証を通るが、`update` 用の RBAC／監査経路は通っていない。自動試験は未整備（`--standby` が実 Discord 経路のみで、模擬 Discord では動かないため。実機のみで確認）。
- V3（更新中の連続送信、実 Discord、WSL）：ユーザーが約 1 秒間隔で `!count` を送り続ける間に `botctl gateway-update` を実行（21:15:00.6〜21:15:01.9、約 1.3 秒、成功）。報告は「22 から 33 まで」（12 件）で、ユーザーの判断は問題なし。**欠落・重複の報告なし**。ただし、更新の窓が約 1.3 秒と短く、約 1 秒間隔の送信では窓に重なったメッセージは 1〜2 件程度と見込まれる。窓での重複排除が実際に働いたか（Core が捨てた件数）は、計測していない。より厳密には、短い間隔（連投）での再試験と、Core 側の重複排除の件数カウンタが要る。
- Interaction（スラッシュ）の重複排除：**コード変更は不要と判断**。`interaction_flow::run` は「ACK が確認できてから実行」で、Discord は Interaction への最初の応答を 1 回だけ受け付ける（2 回目は「既に応答済み」で失敗する、という Discord の仕様に基づく理解）。更新中に旧・新の Gateway が同じ Interaction を受けても、先に ACK した方だけが実行し、後の方は `AckFailed` で実行しない。3 秒を過ぎた古い Interaction を新 Gateway が保留から再生しても ACK が失敗して実行されない。**この挙動は実 Discord では未確認**（2 つの Gateway が同時に同じスラッシュコマンドを受けた場合の実測が要る）。メッセージ（`!` コマンド）は ACK の仕組みがないので、Core の ID 窓で排除している（実機で確認済み）。コンポーネント／モーダルの Interaction も同じ ACK 規則だが、同様に未確認。
- OS 再起動後の自動起動（WSL2 の実 systemd、実 Discord、separate）：`systemctl enable botd` のあと `wsl --shutdown`。再起動で botd が自動で起動し（Core 2 本と Gateway が揃い、ログイン成功）、`!count` は 33 → **34**（保存済みスナップショットから復元）。注意：WSL は端末が開いていないとアイドル（約 25 秒）で VM ごと停止し、その間は botd も止まる（今回も一度停止し、次の起動で自動復帰して状態は失われなかった）。本物の Linux サーバでは起きない。WSL で長時間動かすなら端末を開いておくか `.wslconfig` の `vmIdleTimeout`（未変更）を使う。
- 待機 Gateway の失敗時（実機、WSL、実 Discord、separate）：`/opt/discord-rs/bin/src` を一時的に差し替えて 2 通りを再現（試験後に元へ戻し、`cmp` で一致を確認）。(1) 候補がすぐ終了：操作は `failed`（`ChildExited`）。(2) 候補がログインせず固まる：約 90 秒で `failed`（`StopTimedOut`）、候補は kill。どちらも稼働中の Gateway（PID）と Core（PID）は不変、待機プロセスは残らず、直後の `!count` は 34→**35**（1 件）。未確認：Discord の認証失敗（4004 等）で候補が終了する経路（(1) と同じ「候補の終了」として扱われるはずだが、実際の close code では未試験）、候補が有効化の途中で死んだ場合（`activate` 送信後の失敗は、epoch が上がるので旧 Gateway は Core に戻れない。botd が再起動する Gateway は新しい epoch で attach する）。
- 更新中の連投の再試験（実機、WSL、実 Discord、separate）：Core に重複破棄の件数を出力（`core-N.log` に「重複したメッセージを処理せず破棄しました（累計 N 件）」。ID や内容は出さない）。開始時のカウンターは 35。ユーザーが連投する間に `gateway-update`（21:32:13.6〜14.7、約 1.1 秒、成功、保留 2 件）。結果：最終カウントは **50**（35 から 15 件が処理された）。貼り付けられた返信は 39〜50 で、**飛びも重複もなし**。ただし 46 が 47・48 の後に届いた（返信の順序が入れ替わった。同時に処理した返信が前後しただけで、数は重複していない）。貼り付けの冒頭は 36〜38 の返信が含まれず、送信回数もユーザーの数え直しがないため、15 件すべての送受信の対応は確認していない。**Core の重複破棄の記録は 0 件**：今回も、旧と新が同じメッセージを両方受けて新が再生する、という状況が起きなかった（保留 2 件は Ready など別種のイベントと見られる）。つまり重複排除は、実 Discord では「働く場面」自体をまだ観測できていない（単体試験では働くことを確認済み）。窓の中に旧・新の両方が受けるメッセージを意図的に入れるには、候補を READY にしたまま有効化を遅らせる試験が要る。
- **重複排除が実 Discord で働くことを確認**（実機、WSL、separate、手動の待機 Gateway B と botd 配下の A）：B をログイン済みで待機させ、その間にユーザーが `!count` を 5 回送信（A が 56〜60 を返信）。B を `activate epoch 2` → **保留 15 件**を処理し、**Core が重複を 5 件破棄**（`累計 1〜5 件`、送った 5 件と一致）。ユーザー報告：直後の `!count` は **61 が 1 件だけ**（有効化直後の二重返信の有無は個別の言及なし。ただし破棄の件数は、再生された 5 件が処理されなかったことと整合する）。試験後、B を停止し botd を再起動して元に戻した（B の別ディレクトリの保存値は消えるため、botd 再起動後の数は 60 から再開する）。
- 試験手順の注意（私の誤り）：手動の有効化の epoch は、**現在稼働中の Gateway の epoch より大きく**しなければならない（同じ epoch は順番待ちで、Health がタイムアウトして B が終了する）。`botctl gateway-update` は botd が epoch を管理するので、この問題は起きない。
- 更新の自動試験：`--standby` を模擬 Discord の経路でも動かせるようにした（collector に接続し、`standby-ready` を作って待ち、`activate` で Core に attach してから ready を送る）。`begin_gateway_update` も模擬構成で使える（資格情報を読まず `--mock-discord` を渡す）。実プロセス試験 `gateway_update_replaces_the_gateway_and_keeps_the_cores`：`gateway-update` で新 Gateway が起動して有効化され、**Core の PID は不変**、旧 Gateway は終了、操作は `succeeded`。新 Gateway をクラッシュさせると botd が再起動し、**上がった epoch で同じ Core に attach** する。WSL で 4 並列×15 回で 0 失敗。実 Discord の経路（`run_standby`）とは別実装なので、そちらの保留・再生は引き続き実機でのみ確認している。
